firmware_bb_v6/main.o: ..\Core\Src\main.c ..\Core\Inc\main.h \
  ..\Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal.h \
  ..\Core\Inc\stm32f1xx_hal_conf.h \
  ..\Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_rcc.h \
  ..\Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_def.h \
  ..\Drivers\CMSIS\Device\ST\STM32F1xx\Include\stm32f1xx.h \
  ..\Drivers\CMSIS\Device\ST\STM32F1xx\Include\stm32f103xb.h \
  ..\Drivers\CMSIS\Include\core_cm3.h \
  ..\Drivers\CMSIS\Device\ST\STM32F1xx\Include\system_stm32f1xx.h \
  ..\Drivers\STM32F1xx_HAL_Driver\Inc\Legacy\stm32_hal_legacy.h \
  ..\Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_rcc_ex.h \
  ..\Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_gpio.h \
  ..\Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_gpio_ex.h \
  ..\Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_exti.h \
  ..\Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_dma.h \
  ..\Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_dma_ex.h \
  ..\Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_cortex.h \
  ..\Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_adc.h \
  ..\Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_adc_ex.h \
  ..\Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_flash.h \
  ..\Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_flash_ex.h \
  ..\Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_pwr.h \
  ..\Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_spi.h \
  ..\Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_tim.h \
  ..\Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_tim_ex.h \
  ..\Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_pcd.h \
  ..\Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_ll_usb.h \
  ..\Drivers\STM32F1xx_HAL_Driver\Inc\stm32f1xx_hal_pcd_ex.h \
  ..\USB_DEVICE\App\usb_device.h \
  ..\Middlewares\ST\STM32_USB_Device_Library\Core\Inc\usbd_def.h \
  ..\USB_DEVICE\Target\usbd_conf.h ..\Core\Inc\power_stage.h \
  ..\Core\Inc\analog_monitor.h ..\Core\Inc\input_ui_port.h \
  ..\Core\Inc\input_buttons.h ..\Core\Inc\input_encoder.h \
  ..\Core\Inc\ui_lcd.h ..\Core\Inc\psu_link.h ..\Core\Inc\psu_usb.h
