#include "power_stage.h"
#include "analog_monitor.h"
#include "input_buttons.h"
#include "input_encoder.h"
#include <string.h>

static TIM_HandleTypeDef *s_pwm;
static TIM_HandleTypeDef *s_t3;
static volatile PSU_Status s_ui;
static volatile uint8_t s_ready;
static volatile uint32_t s_ticks;
static uint32_t s_last_adc_seq, s_adc_age_ticks;
static float s_v_filter, s_i_filter, s_vin_filter;
static uint8_t s_first;
static float s_cv_int, s_cc_int, s_duty;
static float s_cv_target;
static float s_vref_ramped;
static uint16_t s_outer_count;
static uint32_t s_run_ticks;
static volatile PSU_Tuning s_cfg;
static volatile uint8_t s_cfg_dirty, s_save_requested, s_save_event;
static uint32_t s_change_at;
/* PSU_FAULT_IO_V1: PC13 LED (Blue Pill active-low), PC14 active-high buzzer.
 * Override polarities below for an external LED or low-level-trigger buzzer.
 * PC14 cannot be used as GPIO while LSE oscillator is active. */
#ifndef PSU_LED_ACTIVE_LOW
#define PSU_LED_ACTIVE_LOW 1U
#endif
#ifndef PSU_BUZZER_ACTIVE_HIGH
#define PSU_BUZZER_ACTIVE_HIGH 1U
#endif
#define PSU_ALARM_PERIOD_MS 500U
#define PSU_ALARM_ON_MS     200U
static volatile uint32_t s_fault_since_ms;

static void psu_indicators_write(uint8_t output_on, uint8_t buzzer_on) {
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13,
        (output_on ^ PSU_LED_ACTIVE_LOW) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_14,
        (buzzer_on == PSU_BUZZER_ACTIVE_HIGH) ? GPIO_PIN_SET : GPIO_PIN_RESET);
}
static void psu_indicators_init(void) {
    GPIO_InitTypeDef io={0};
    __HAL_RCC_GPIOC_CLK_ENABLE();
    /* Set inactive levels before switching pins to outputs. */
    psu_indicators_write(0U, 0U);
    io.Pin=GPIO_PIN_13 | GPIO_PIN_14;
    io.Mode=GPIO_MODE_OUTPUT_PP;
    io.Pull=GPIO_NOPULL;
    io.Speed=GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOC,&io);
    psu_indicators_write(0U, 0U);
}
/* Implemented in psu_flash.c; never erase/program Flash from TIM3 ISR. */
#include "psu_flash.h"
static const PSU_Tuning s_defaults = {
    1000U, 6000U, 5000U, 120000U,
    30000U, 6000U, 7000U, 40000U,
    28000U, 5000U, 970U,
    2000U, 8000U /* rise 2V/s; fall 8V/s */
};

static float clampf(float x, float lo, float hi) { return x<lo?lo:(x>hi?hi:x); }
/* PSU_MULTIMODE_TRIAL_V1: 3-mode 20 kHz experimental modulation.
 * IR2184 IN=HIGH -> HO on, IN=LOW -> LO on. Both high-sides are
 * PWM'd every cycle (<=97%) to replenish bootstrap; NO nanosecond refresh.
 * d_buck * Vin ~= d_boost_high * Vref (CCM ideal volt-second balance).
 * The topology label has Schmitt hysteresis; the duty pair is continuously
 * interpolated across the two boundary bands to avoid mode-step spikes.
 */
#define MM_TRANSITION_IN_V  0.75f
#define MM_TRANSITION_OUT_V 3.50f
#define MM_BOOTSTRAP_HS_MAX_PCT 95.0f
#define MM_PI_CORR_MAX_PCT 30.0f
#define MM_PI_CORR_STOP_PCT (-29.0f)

static float mm_abs(float x) { return x<0.0f ? -x : x; }
static PSU_Mode mm_mode(PSU_Mode old, float vin_minus_vout) {
    if (old == PSU_BUCK) {
        if (vin_minus_vout < MM_TRANSITION_IN_V) return PSU_BB;
        return PSU_BUCK;
    }
    if (old == PSU_BOOST) {
        if (vin_minus_vout > -MM_TRANSITION_IN_V) return PSU_BB;
        return PSU_BOOST;
    }
    if (vin_minus_vout > MM_TRANSITION_OUT_V) return PSU_BUCK;
    if (vin_minus_vout < -MM_TRANSITION_OUT_V) return PSU_BOOST;
    return PSU_BB;
}

static void mm_duties(float vin, float wanted, float measured_vout,
                      float correction, float max_high_pct,
                      float *d1, float *d2) {
    float a, b, x, weight, ratio;
    float d1bb, d2bb;
    float w1, w2;
    vin=clampf(vin,0.2f,100.0f);
    wanted=clampf(wanted,0.2f,100.0f);
    /* d1=Q1 high-side duty, d2=Q2 high-side duty, BOTH PWM1. */
    d1bb=100.0f*wanted/(vin+wanted);
    d2bb=100.0f*vin/(vin+wanted);
    /* Mode blending is based on measured Vout but the ideal feedforward
       follows the ramped voltage target to avoid hard startup jumps. */
    x=vin-measured_vout;
    weight=clampf((mm_abs(x)-MM_TRANSITION_IN_V)/
                  (MM_TRANSITION_OUT_V-MM_TRANSITION_IN_V),0.0f,1.0f);
    if (x>=0.0f) {
        /* Buck: boost high-side nearly pass-through, still refreshed. */
        b=d2bb+weight*(max_high_pct-d2bb);
        a=b*wanted/vin;
        w1=0.5f+0.5f*weight;
        w2=1.0f-w1;
    } else {
        /* Boost: buck high-side nearly pass-through, still refreshed. */
        a=d1bb+weight*(max_high_pct-d1bb);
        b=a*vin/wanted;
        w2=0.5f+0.5f*weight;
        w1=1.0f-w2;
    }
    /* Positive control effort raises Vout by raising buck HS duty
       and/or lowering boost HS duty; CC penalty has the opposite sign. */
    ratio=clampf(correction,-MM_PI_CORR_MAX_PCT,MM_PI_CORR_MAX_PCT);
    *d1=clampf(a+w1*ratio,PSU_DUTY_MIN,max_high_pct);
    *d2=clampf(b-w2*ratio,PSU_DUTY_MIN,max_high_pct);
}

static uint16_t clampi(int32_t x, uint16_t lo, uint16_t hi) {
    return (uint16_t)(x<(int32_t)lo?lo:(x>(int32_t)hi?hi:x));
}
static uint32_t ccr(float percent) {
    uint32_t period = __HAL_TIM_GET_AUTORELOAD(s_pwm) + 1U;
    float c = (float)period * clampf(percent, 0.0f, 97.0f) * 0.01f;
    return (uint32_t)(c + 0.5f);
}
static void pwm_write(float a, float b) {
    __HAL_TIM_SET_COMPARE(s_pwm, TIM_CHANNEL_1, ccr(a));
    __HAL_TIM_SET_COMPARE(s_pwm, TIM_CHANNEL_2, ccr(b));
    s_ui.duty_buck_pct=a;
    s_ui.duty_boost_pct=b;
}
static void pwm_zero(void) {
    __HAL_TIM_SET_COMPARE(s_pwm, TIM_CHANNEL_1, 0U);
    __HAL_TIM_SET_COMPARE(s_pwm, TIM_CHANNEL_2, 0U);
    s_ui.duty_buck_pct=0.0f;
    s_ui.duty_boost_pct=0.0f;
    s_ui.duty_applied_pct=0.0f;
}
static void reset_ramp(void) { s_vref_ramped=0.0f; s_ui.vref_ramped_v=0.0f; }
static void reset_pi(void) {
    s_cv_int=0.0f; s_cv_target=0.0f;
    s_cc_int=0.0f; s_duty=0.0f;
    s_outer_count=0U; s_first=0U;
}
void PowerStage_OffNow(void) {
    if (!s_ready) return;
    pwm_zero();
    if (s_ui.state==PSU_ON) s_ui.state=PSU_OFF;
    reset_pi(); reset_ramp();
    psu_indicators_write(0U, 0U);
    /* PA10 deliberately remains HIGH per hardware requirement. */
}
static void trip(PSU_Error e) {
    pwm_zero();
    reset_pi(); reset_ramp();
    s_ui.error=e;
    s_ui.state=PSU_FAULT;
    s_fault_since_ms=HAL_GetTick();
    psu_indicators_write(0U, 1U); /* immediate latched fault indication */
}
static uint32_t timer_hz(TIM_HandleTypeDef *t, uint8_t apb2) {
    RCC_ClkInitTypeDef cfg;
    uint32_t lat, clk, div;
    HAL_RCC_GetClockConfig(&cfg,&lat);
    clk=apb2 ? HAL_RCC_GetPCLK2Freq() : HAL_RCC_GetPCLK1Freq();
    if (apb2 ? cfg.APB2CLKDivider != RCC_HCLK_DIV1 : cfg.APB1CLKDivider != RCC_HCLK_DIV1) clk*=2U;
    div=(t->Instance->PSC+1U)*(t->Instance->ARR+1U);
    return div ? clk/div : 0U;
}
HAL_StatusTypeDef PowerStage_Init(TIM_HandleTypeDef *pwm,TIM_HandleTypeDef *timer) {
    GPIO_InitTypeDef g={0};
    s_ready=0U;
    psu_indicators_init();
    s_fault_since_ms=HAL_GetTick();
    memset((void*)&s_ui,0,sizeof(s_ui));
    s_ui.state=PSU_OFF;
    s_ui.vset_cv=500U;
    s_ui.iset_ca=100U;
    s_ui.digit=2U; /* 0.1V */
    s_ui.editing=PSU_EDIT_V;
    s_cfg=s_defaults;
    {
        PSU_Tuning stored;
        uint32_t vset_mv, iset_ma;
        if (PSU_Flash_Load(&stored, &vset_mv, &iset_ma) &&
            vset_mv>=3000U && vset_mv<=stored.vset_max_mv &&
            iset_ma>=100U && iset_ma<=stored.iset_max_ma &&
            (vset_mv%10U)==0U && (iset_ma%10U)==0U) {
            s_cfg=stored;
            s_ui.vset_cv=(uint16_t)(vset_mv/10U);
            s_ui.iset_ca=(uint16_t)(iset_ma/10U);
        }
    }
    s_cfg_dirty=0U;s_save_requested=0U;s_save_event=0U;
    s_change_at=HAL_GetTick();
    if (!pwm || !timer || pwm->Instance!=TIM1 || timer->Instance!=TIM3 ||
        timer_hz(pwm,1U)!=PSU_PWM_HZ || timer_hz(timer,0U)!=PSU_CONTROL_HZ ||
        pwm->Init.CounterMode!=TIM_COUNTERMODE_UP ||
        (pwm->Instance->CCMR1 & TIM_CCMR1_OC1M)!=TIM_OCMODE_PWM1 ||
        (pwm->Instance->CCMR1 & TIM_CCMR1_OC2M)!=(TIM_OCMODE_PWM1<<8U)) {
        s_ui.state=PSU_FAULT; s_ui.error=PSU_ERR_TIMERS;
        psu_indicators_write(0U, 1U);
        return HAL_ERROR;
    }
    s_pwm=pwm; s_t3=timer;
    __HAL_RCC_GPIOA_CLK_ENABLE();
    HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,GPIO_PIN_RESET);
    g.Pin=GPIO_PIN_10; g.Mode=GPIO_MODE_OUTPUT_PP;
    g.Speed=GPIO_SPEED_FREQ_HIGH; g.Pull=GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA,&g);
    pwm_zero(); reset_pi(); reset_ramp();
    s_ticks=0U; s_last_adc_seq=0U; s_adc_age_ticks=PSU_ADC_STALE_TICKS+1U;
    s_run_ticks=0U; s_first=0U;
    if (HAL_TIM_PWM_Start(s_pwm,TIM_CHANNEL_1)!=HAL_OK ||
        HAL_TIM_PWM_Start(s_pwm,TIM_CHANNEL_2)!=HAL_OK) {
        HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,GPIO_PIN_RESET);
        s_ui.state=PSU_FAULT; s_ui.error=PSU_ERR_TIMERS;
        psu_indicators_write(0U, 1U);
        return HAL_ERROR;
    }
    /* /SD stays HIGH from this point onward, even for OFF and FAULT.
       With IR2184, this actively drives LO when IN=LOW. */
    HAL_GPIO_WritePin(GPIOA,GPIO_PIN_10,GPIO_PIN_SET);
    s_ready=1U;
    return HAL_OK;
}

/* Called exclusively by TIM3 update IRQ @ 2kHz. No HAL polling, printf,
 * drawing, or HAL_Delay. Reads the latest completed DMA 30-scan averages.
 * Fast filter settles in a few milliseconds; main's slower IIR is for UI.
 */
void PowerStage_TIM3_Callback(TIM_HandleTypeDef *htim) {
    uint32_t sums[4],seq;
    float v,i,vin,vset,iset,delta,base,err,cc_over,cc_reduction,command;
    PSU_Mode mode;
    if (!s_ready || htim!=s_t3 || htim->Instance!=TIM3) return;
    ++s_ticks;
    if (!AnalogMonitor_GetFastRaw(sums,&seq)) { if (s_ui.state==PSU_ON) trip(PSU_ERR_ADC); return; }
    if (seq!=s_last_adc_seq) {
        s_last_adc_seq=seq; s_adc_age_ticks=0U;
        /* 3.3 / (4095 * 30) => raw ADC count sums converted to volts.
           1mOhm shunt and gain200 => 0.2V per amp. */
        v=(float)sums[0]*(3.3f/(4095.0f*30.0f))*22.0f;
        i=(float)sums[1]*(3.3f/(4095.0f*30.0f))/0.2f;
        vin=(float)sums[3]*(3.3f/(4095.0f*30.0f))*22.0f;
        if (!s_first) {s_v_filter=v; s_i_filter=i; s_vin_filter=vin; s_first=1U;}
        else {
            s_v_filter+=0.15f*(v-s_v_filter);
            s_i_filter+=0.15f*(i-s_i_filter);
            s_vin_filter+=0.15f*(vin-s_vin_filter);
        }
        s_ui.vout_v=s_v_filter;
        s_ui.iout_a=s_i_filter;
        s_ui.vin_v=s_vin_filter;
    } else if (s_adc_age_ticks<0xFFFFFFFFU) ++s_adc_age_ticks;
    if (s_ui.state!=PSU_ON) return;
    ++s_run_ticks;
    if ((s_run_ticks%PSU_CONTROL_HZ)==0U) ++s_ui.running_seconds;
    if (s_adc_age_ticks>PSU_ADC_STALE_TICKS) {trip(PSU_ERR_ADC);return;}
    if (!(s_vin_filter>=(float)s_cfg.vin_min_mv*0.001f && s_vin_filter<=(float)s_cfg.vin_max_mv*0.001f)) {trip(PSU_ERR_VIN);return;}
    if (!(s_v_filter>=0.0f && s_v_filter<(float)s_cfg.ovp_mv*0.001f)) {trip(PSU_ERR_OVP);return;}
    if (!(s_i_filter>=-0.5f && s_i_filter<(float)s_cfg.ocp_ma*0.001f)) {trip(PSU_ERR_OCP);return;}
    vset=s_vref_ramped;
    iset=(float)s_ui.iset_ca*0.01f;
    mode=mm_mode(s_ui.mode,s_vin_filter-s_v_filter);
    /* No reset on a mode label transition: both modulator duties are
       continuous functions of Vin and measured Vout across boundary bands. */
    s_ui.mode=mode;
    if (++s_outer_count>=10U) { /* voltage loop and voltage ramp: 200 Hz */
        float wanted=(float)s_ui.vset_cv*0.01f;
        float rise_step=(float)s_cfg.v_rise_mv_s*0.000005f;
        float fall_step=(float)s_cfg.v_fall_mv_s*0.000005f;
        s_outer_count=0U;
        if (s_vref_ramped < wanted) {
            s_vref_ramped+=rise_step;
            if (s_vref_ramped>wanted) s_vref_ramped=wanted;
        } else if (s_vref_ramped > wanted) {
            s_vref_ramped-=fall_step;
            if (s_vref_ramped<wanted) s_vref_ramped=wanted;
        }
        s_ui.vref_ramped_v=s_vref_ramped;
        vset=s_vref_ramped;
        err=vset-s_v_filter;
        base=((float)s_cfg.cv_kp_milli*0.001f)*err;
        if (s_cc_int<0.01f || err<0.0f)
            s_cv_int=clampf(s_cv_int+
                ((float)s_cfg.cv_ki_milli*0.001f)*0.005f*err,
                -MM_PI_CORR_MAX_PCT,MM_PI_CORR_MAX_PCT);
        s_cv_target=clampf(base+s_cv_int,
                          -MM_PI_CORR_MAX_PCT,MM_PI_CORR_MAX_PCT);
        /* Keep integrator bounded under saturation. */
        if ((base+s_cv_int>=MM_PI_CORR_MAX_PCT && err>0.0f) ||
            (base+s_cv_int<=-MM_PI_CORR_MAX_PCT && err<0.0f))
            s_cv_int=clampf(s_cv_int-
                ((float)s_cfg.cv_ki_milli*0.001f)*0.005f*err,
                -MM_PI_CORR_MAX_PCT,MM_PI_CORR_MAX_PCT);
    }
    cc_over=s_i_filter-iset;
    s_cc_int=clampf(s_cc_int+
        ((float)s_cfg.cc_ki_milli*0.001f)*0.0005f*cc_over,
        0.0f,2.0f*MM_PI_CORR_MAX_PCT);
    cc_reduction=clampf(((float)s_cfg.cc_kp_milli*0.001f)*
                        (cc_over>0.0f?cc_over:0.0f)+s_cc_int,
                        0.0f,2.0f*MM_PI_CORR_MAX_PCT);
    command=s_cv_target-cc_reduction;
    /* Safe no-injection clamp remains as in prior CV/CC firmware. */
    if (s_v_filter>vset+0.25f || vset<0.30f ||
        command<=MM_PI_CORR_STOP_PCT) {
        pwm_zero(); s_duty=0.0f;
        return;
    }
    /* Command slew limiting; negative correction may act immediately
       to limit current, whereas positive correction ramps slowly. */
    delta=PSU_DUTY_RAMP_PCT_PER_S/PSU_CONTROL_HZ;
    if (command>s_duty+delta) s_duty+=delta;
    else s_duty=command;
    {
        float d1,d2;
        float limit=clampf((float)s_cfg.duty_max_permille*0.1f,
                           PSU_DUTY_MIN, MM_BOOTSTRAP_HS_MAX_PCT);
        mm_duties(s_vin_filter,vset,s_v_filter,s_duty,limit,&d1,&d2);
        pwm_write(d1,d2);
        s_ui.duty_applied_pct=(mode==PSU_BOOST)?(100.0f-d2):d1;
    }
}


void PowerStage_Handle(void) {
    static const uint16_t vst[4]={1000U,100U,10U,1U};
    static const uint16_t ist[3]={100U,10U,1U};
    int32_t change,step,next;
    uint32_t mask;
    if (!s_ready) return;
    if (Button_TakePressedEvent(BUTTON_1)) {
        mask=__get_PRIMASK();__disable_irq();
        if (s_ui.state==PSU_FAULT) {
            /* One BTN1 press: keep power OFF, clear latched fault and silence PC14.
             * A separate press is required to start again. */
            pwm_zero(); reset_pi(); reset_ramp();
            s_ui.error=PSU_ERR_NONE;
            s_ui.state=PSU_OFF;
            psu_indicators_write(0U, 0U);
        }
        else if (s_ui.state==PSU_ON) {
            PowerStage_OffNow();
            /* Any pending parameters can now be saved without stopping PI. */
        }
        else if (s_ui.state==PSU_OFF) {
            if (s_adc_age_ticks<PSU_ADC_STALE_TICKS &&
                s_vin_filter>=PSU_VIN_MIN_V && s_vin_filter<=PSU_VIN_MAX_V &&
                s_v_filter>=0.0f && s_v_filter<(float)s_cfg.ovp_mv*0.001f &&
                s_i_filter>=-0.5f && s_i_filter<(float)s_cfg.ocp_ma*0.001f) {
                reset_pi(); reset_ramp(); pwm_zero(); s_ui.state=PSU_ON;
                psu_indicators_write(1U, 0U);
            }
        }
        if (mask==0U) __enable_irq();
    }
    if (Button_TakePressedEvent(BUTTON_2)) {
        s_ui.editing=(s_ui.editing==PSU_EDIT_V)?PSU_EDIT_I:PSU_EDIT_V;
        s_ui.digit=(s_ui.editing==PSU_EDIT_V)?2U:1U;
    }
    if (Button_TakePressedEvent(BUTTON_ENCODER_SWITCH)) {
        if (s_ui.editing==PSU_EDIT_V) s_ui.digit=(uint8_t)((s_ui.digit+1U)%4U);
        else s_ui.digit=(uint8_t)((s_ui.digit+1U)%3U);
    }
    change=-Encoder_TakeDelta(); /* reverse current EC-11 direction */
    if (change!=0) {
        step=(int32_t)((s_ui.editing==PSU_EDIT_V)?vst[s_ui.digit]:ist[s_ui.digit]);
        mask=__get_PRIMASK();__disable_irq();
        if (s_ui.editing==PSU_EDIT_V) {
            next=(int32_t)s_ui.vset_cv + change*step;
            s_ui.vset_cv=clampi(next,PSU_VSET_MIN_CV,(uint16_t)(s_cfg.vset_max_mv/10U));
            PowerStage_MarkDirty();
        } else {
            next=(int32_t)s_ui.iset_ca + change*step;
            s_ui.iset_ca=clampi(next,PSU_ISET_MIN_CA,(uint16_t)(s_cfg.iset_max_ma/10U));
            PowerStage_MarkDirty();
        }
        if (mask==0U) __enable_irq();
    }
    /* Fault beep pattern: 200ms ON, 300ms OFF. HAL_GPIO_WritePin is safe
     * here in the foreground; no LCD/USB work runs inside TIM3 ISR. */
    if (s_ui.state==PSU_FAULT) {
        uint32_t phase=(uint32_t)(HAL_GetTick()-s_fault_since_ms) % PSU_ALARM_PERIOD_MS;
        psu_indicators_write(0U, phase < PSU_ALARM_ON_MS);
    }
    PowerStage_StoragePoll(); /* Flash writes only with power OFF. */
}
PSU_Status PowerStage_GetStatus(void) {
    PSU_Status r;
    uint32_t primask=__get_PRIMASK();
    __disable_irq();
    r.state=s_ui.state;r.mode=s_ui.mode;r.editing=s_ui.editing;
    r.error=s_ui.error;r.vset_cv=s_ui.vset_cv;r.iset_ca=s_ui.iset_ca;
    r.digit=s_ui.digit;r.duty_buck_pct=s_ui.duty_buck_pct;
    r.duty_boost_pct=s_ui.duty_boost_pct;r.duty_applied_pct=s_ui.duty_applied_pct;
    r.vout_v=s_ui.vout_v;r.iout_a=s_ui.iout_a;r.vin_v=s_ui.vin_v;
    r.vref_ramped_v=s_ui.vref_ramped_v;
    r.running_seconds=s_ui.running_seconds;
    if (primask==0U) __enable_irq();
    return r;
}

void PowerStage_GetTuning(PSU_Tuning *out) {
    uint32_t mask;
    if (!out) return;
    mask=__get_PRIMASK(); __disable_irq();
    *out=s_cfg;
    if (mask==0U) __enable_irq();
}

uint8_t PowerStage_SetParam(const char *name,uint32_t value) {
    PSU_Tuning next;
    uint32_t mask;
    uint8_t is_gain=0U;
    if (!name || !s_ready) return 0U;
    PowerStage_GetTuning(&next);
    if (!strcmp(name,"CV_KP") && value<=20000U) {next.cv_kp_milli=value;is_gain=1U;}
    else if (!strcmp(name,"CV_KI") && value<=100000U) {next.cv_ki_milli=value;is_gain=1U;}
    else if (!strcmp(name,"CC_KP") && value<=50000U) {next.cc_kp_milli=value;is_gain=1U;}
    else if (!strcmp(name,"CC_KI") && value<=1000000U) {next.cc_ki_milli=value;is_gain=1U;}
    else if (!strcmp(name,"OVP_MV") && value>=5000U && value<=30000U) next.ovp_mv=value;
    else if (!strcmp(name,"OCP_MA") && value>=500U && value<=6500U) next.ocp_ma=value;
    else if (!strcmp(name,"VIN_MIN_MV") && value>=5000U && value<=35000U) next.vin_min_mv=value;
    else if (!strcmp(name,"VIN_MAX_MV") && value>=10000U && value<=40000U) next.vin_max_mv=value;
    else if (!strcmp(name,"VSET_MAX_MV") && value>=3000U && value<=28000U && (value%10U)==0U) next.vset_max_mv=value;
    else if (!strcmp(name,"ISET_MAX_MA") && value>=100U && value<=5000U && (value%10U)==0U) next.iset_max_ma=value;
    else if (!strcmp(name,"DUTY_MAX_PM") && value>=100U && value<=970U) next.duty_max_permille=value;
    else if (!strcmp(name,"V_RISE_MV_S") && value>=100U && value<=30000U) next.v_rise_mv_s=value;
    else if (!strcmp(name,"V_FALL_MV_S") && value>=100U && value<=30000U) next.v_fall_mv_s=value;
    else if (!strcmp(name,"VSET_MV") && value>=3000U && value<=next.vset_max_mv && (value%10U)==0U) {
        mask=__get_PRIMASK();__disable_irq(); s_ui.vset_cv=(uint16_t)(value/10U);
        if (mask==0U) __enable_irq();
        PowerStage_MarkDirty();
        return 1U;
    } else if (!strcmp(name,"ISET_MA") && value>=100U && value<=next.iset_max_ma && (value%10U)==0U) {
        mask=__get_PRIMASK();__disable_irq(); s_ui.iset_ca=(uint16_t)(value/10U);
        if (mask==0U) __enable_irq();
        PowerStage_MarkDirty();
        return 1U;
    } else return 0U;
    /* Keep protective thresholds stricter than hardware-authorized setpoints.
       For OFF and ON, reject inconsistent settings atomically. */
    if (next.vset_max_mv+500U>next.ovp_mv ||
        next.iset_max_ma+200U>next.ocp_ma ||
        next.vin_min_mv+1000U>=next.vin_max_mv ||
        next.duty_max_permille<100U) return 0U;
    mask=__get_PRIMASK();__disable_irq();
    s_cfg=next;
    if (s_ui.vset_cv>next.vset_max_mv/10U) s_ui.vset_cv=(uint16_t)(next.vset_max_mv/10U);
    if (s_ui.iset_ca>next.iset_max_ma/10U) s_ui.iset_ca=(uint16_t)(next.iset_max_ma/10U);
    if (is_gain) reset_pi(); /* No integral jump after gain changes. */
    if (mask==0U) __enable_irq();
    PowerStage_MarkDirty();
    return 1U;
}

void PowerStage_MarkDirty(void) {
    s_cfg_dirty=1U;
    s_change_at=HAL_GetTick();
}
void PowerStage_RequestSave(void) { s_save_requested=1U; }
uint8_t PowerStage_TakeSaveEvent(void) {
    uint8_t event=s_save_event;
    s_save_event=0U;
    return event;
}
void PowerStage_StoragePoll(void) {
    PSU_Tuning c;
    uint32_t vset, iset;
    if (!s_ready || s_ui.state!=PSU_OFF ||
        (!s_cfg_dirty && !s_save_requested)) return;
    /* Quiet for 5s before automatic storage; explicit SAVE is immediate OFF. */
    if (!s_save_requested && (uint32_t)(HAL_GetTick()-s_change_at)<5000U) return;
    PowerStage_GetTuning(&c);
    {
        PSU_Status st=PowerStage_GetStatus();
        vset=(uint32_t)st.vset_cv*10U;
        iset=(uint32_t)st.iset_ca*10U;
    }
    if (PSU_Flash_Save(&c,vset,iset)) {
        s_cfg_dirty=0U; s_save_requested=0U; s_save_event=1U;
    } else {
        /* No tight retry loop on HAL Flash failure; explicit SAVE can retry. */
        s_save_requested=0U; s_cfg_dirty=0U; s_save_event=2U;
    }
}
